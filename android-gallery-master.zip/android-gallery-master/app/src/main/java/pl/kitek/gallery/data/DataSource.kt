package pl.kitek.gallery.data

object DataSource {
    val ITEMS = listOf(
            GalleryItem(1, "https://wallpaperbrowse.com/media/images/3848765-wallpaper-images-download.jpg", "https://wallpaperbrowse.com/media/images/3848765-wallpaper-images-download.jpg"),
            GalleryItem(2, "https://wallpaperbrowse.com/media/images/Dubai-Photos-Images-Photos-of-Dubai-800x600.jpg", "https://wallpaperbrowse.com/media/images/Dubai-Photos-Images-Photos-of-Dubai-800x600.jpg"),
            GalleryItem(3, "https://wallpaperbrowse.com/media/images/image-slider-2.jpg", "https://wallpaperbrowse.com/media/images/image-slider-2.jpg"),
            GalleryItem(4, "https://wallpaperbrowse.com/media/images/images-13.jpg", "https://wallpaperbrowse.com/media/images/images-13.jpg"),
            GalleryItem(5, "https://wallpaperbrowse.com/media/images/BMW-4-series-gran-coupe-images-and-videos-1920x1200-04.jpg.asset.1487328216285.jpg", "https://wallpaperbrowse.com/media/images/BMW-4-series-gran-coupe-images-and-videos-1920x1200-04.jpg.asset.1487328216285.jpg"),
            GalleryItem(6, "https://wallpaperbrowse.com/media/images/430b434410a6d2eb951db07c08ec445c.jpg", "https://wallpaperbrowse.com/media/images/430b434410a6d2eb951db07c08ec445c.jpg"),
            GalleryItem(7, "https://wallpaperbrowse.com/media/images/5253413-images-wallpaper.jpg", "https://wallpaperbrowse.com/media/images/5253413-images-wallpaper.jpg"),
            GalleryItem(8, "https://wallpaperbrowse.com/media/images/1159701.jpg", "https://wallpaperbrowse.com/media/images/1159701.jpg")
    )
}
