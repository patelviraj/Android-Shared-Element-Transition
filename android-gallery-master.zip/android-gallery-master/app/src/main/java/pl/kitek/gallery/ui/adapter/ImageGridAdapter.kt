package pl.kitek.gallery.ui.adapter

import android.support.v4.view.ViewCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.squareup.picasso.Picasso
import pl.kitek.gallery.R
import pl.kitek.gallery.data.GalleryItem
import pl.kitek.gallery.ui.adapter.ImageGridAdapter.ViewHolder
import pl.kitek.gallery.ui.view.AspectRatioImageView

class ImageGridAdapter(val items: List<GalleryItem>,
                       val onItemClickListener: OnItemClickListener? = null) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder as ViewHolder
        holder.bind(items[position], onItemClickListener)
    }

    override fun getItemCount() = items.size

    class ViewHolder(parent: View) : RecyclerView.ViewHolder(parent) {
        val imageView: ImageView = itemView.findViewById<ImageView>(R.id.listItemImage)

        fun bind(item: GalleryItem, onItemClickListener: OnItemClickListener?) {
            imageView.setOnClickListener({ onItemClickListener?.onClick(item, it) })
            imageView.tag = GalleryItem.transitionName(item.id)
            ViewCompat.setTransitionName(imageView, GalleryItem.transitionName(item.id))
            Picasso.with(imageView.context).load(item.thumbnailURL).into(imageView)
        }
    }

    interface OnItemClickListener {
        fun onClick(item: GalleryItem, view: View)
    }
}
