# android-gallery

Shared element transition example with RecyclerView and ViewPager.

![alt text](https://github.com/kitek/android-gallery/blob/master/img/76Zrp8.gif)
