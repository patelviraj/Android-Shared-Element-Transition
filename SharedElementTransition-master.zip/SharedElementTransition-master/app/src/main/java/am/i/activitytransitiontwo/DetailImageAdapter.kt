package am.i.activitytransitiontwo

import am.i.activitytransitiontwo.R.id.image
import android.app.Activity
import android.support.v4.app.ActivityCompat
import android.support.v4.view.ViewCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.ImageView
import kotlinx.android.synthetic.main.abc_activity_chooser_view.view.*

class DetailImageAdapter(private val activity: Activity,
                         var images: List<Image>,
                         private val currentPos: Int) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parentView: ViewGroup, itemType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parentView.context).inflate(R.layout.detail_item, parentView, false)
        return DetailImageViewHolder(view)

    }

    override fun getItemCount() = images.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val image: Image = images[position]
        viewHolder as DetailImageViewHolder
        viewHolder.bind(images[position])

        /*viewHolder.image.tag = "Image_$position"
        ViewCompat.setTransitionName(viewHolder.image, "Image_$position")
        viewHolder.image.setImageResource(image.image)

        if (position == currentPos) {
            viewHolder.image.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    viewHolder.image.viewTreeObserver.removeOnPreDrawListener(this)
                    ActivityCompat.startPostponedEnterTransition(activity)
                    return true
                }
            })
        }*/
    }

    inner class DetailImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val image = itemView.findViewById<ImageView>(R.id.detailItemImage)

        fun bind(galleryItem: Image) {
            /*image.tag = "Image_$adapterPosition"
            ViewCompat.setTransitionName(image,"Image_$adapterPosition")
            image.setImageResource(galleryItem.image)*/

            image.tag = "Image_$adapterPosition"
            ViewCompat.setTransitionName(image, "Image_$adapterPosition")
            image.setImageResource(galleryItem.image)

            if (adapterPosition == currentPos) {
                image.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        image.viewTreeObserver.removeOnPreDrawListener(this)
                        ActivityCompat.startPostponedEnterTransition(activity)
                        return true
                    }
                })
            }
        }

    }

}