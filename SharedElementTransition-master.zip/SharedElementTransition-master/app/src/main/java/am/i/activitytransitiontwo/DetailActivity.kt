package am.i.activitytransitiontwo

import am.i.activitytransitiontwo.MainActivity.Companion.EXTRA_CURRENT_ALBUM_POSITION
import am.i.activitytransitiontwo.MainActivity.Companion.EXTRA_STARTING_ALBUM_POSITION
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.app.SharedElementCallback
import android.support.v4.view.ViewCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.PagerSnapHelper
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    private lateinit var detailImageAdapter: DetailImageAdapter
    private lateinit var imageData: ImageData

    private var isReturning: Boolean = false
    private var startingPosition: Int = 0
    private var currentPosition: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        ActivityCompat.postponeEnterTransition(this)
        ActivityCompat.setEnterSharedElementCallback(this, enterElementCallback)

        imageData = intent.extras.getParcelable("IMAGE_DATA")

        startingPosition = intent.extras.getInt("selectedPosition")
        currentPosition = savedInstanceState?.getInt(SAVED_CURRENT_PAGE_POSITION) ?: startingPosition

        initViews()
//        prepareTransitions()
        resetScrolledPosition()
    }

    override fun onSaveInstanceState(outState: Bundle?) {
        super.onSaveInstanceState(outState)
        outState?.putInt(SAVED_CURRENT_PAGE_POSITION, currentPosition)
    }

    private fun initViews() {
        val snapHelper = PagerSnapHelper()
        snapHelper.attachToRecyclerView(detailGallery)
        detailImageAdapter = DetailImageAdapter(this, imageData.images, startingPosition)
        detailGallery.adapter = detailImageAdapter
        detailGallery.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    val selectedView = snapHelper.findSnapView(detailGallery.layoutManager)
                    selectedView?.let {
                        val selectedPosition = detailGallery.layoutManager?.getPosition(selectedView)
                        selectedPosition?.let { onItemSelected(selectedPosition) }
                    }
                }
            }
        })
    }

    private fun resetScrolledPosition() {
//        val position = imageData.images.indexOfFirst { it.selected }
        imageData.images = imageData.images.mapIndexed { index, galleryItem ->
            when {
                index == startingPosition -> {
                    galleryItem.copy(selected = true)
                }
                galleryItem.selected -> galleryItem.copy(selected = false)
                else -> galleryItem
            }
        }
        detailImageAdapter.images = imageData.images
        detailGallery.scrollToPosition(startingPosition)
        supportStartPostponedEnterTransition()
    }


    private fun onItemSelected(position: Int) {
        currentPosition = position
        imageData.images = imageData.images.mapIndexed { index, galleryItem ->
            when {
                index == position -> galleryItem.copy(selected = true)
                galleryItem.selected -> galleryItem.copy(selected = false)
                else -> galleryItem
            }
        }
    }

    override fun finishAfterTransition() {
        isReturning = true
        val data = Intent()
        data.putExtra(EXTRA_STARTING_ALBUM_POSITION, startingPosition)
        data.putExtra(EXTRA_CURRENT_ALBUM_POSITION, currentPosition)
        setResult(Activity.RESULT_OK, data)
        super.finishAfterTransition()
    }

    override fun onBackPressed() {
        /*var resultIntent = Intent()
        resultIntent = resultIntent.putExtra("IMAGE_DATA", imageData)
        setResult(Activity.RESULT_OK, resultIntent)*/
        supportFinishAfterTransition()
        super.onBackPressed()

    }

    private fun prepareTransitions() {

        setEnterSharedElementCallback(
                object : SharedElementCallback() {
                    override fun onMapSharedElements(names: List<String>?, sharedElements: MutableMap<String, View>?) {
//                        val selectedPosition = imageData.images.indexOfFirst { it.selected }
//                        val selectedViewHolder = detailGallery.findViewHolderForAdapterPosition(selectedPosition)

                        val newTransitionName = "Image_$currentPosition"
                        val newSharedElement = detailGallery.findViewWithTag<ImageView>(newTransitionName)
                                ?: return

//                        Log.e("Passing SharedElement", "Passing SharedElement")
                        sharedElements!![names!![0]] = newSharedElement
                    }
                })
    }

    private val enterElementCallback: SharedElementCallback = object : SharedElementCallback() {
        override fun onMapSharedElements(names: MutableList<String>, sharedElements: MutableMap<String, View>) {
            if (isReturning) {
//                val sharedElement = imagePagerAdapter?.getView(currentPosition)
                val newTransitionName = "Image_$currentPosition"
                val sharedElement = detailGallery.findViewWithTag<ImageView>(newTransitionName)
                        ?: return
                if (startingPosition != currentPosition) {
                    names.clear()
                    names.add(ViewCompat.getTransitionName(sharedElement)!!)

                    sharedElements.clear()
                    sharedElements.put(ViewCompat.getTransitionName(sharedElement)!!, sharedElement)
                }
            }else{
                val selectedPosition = imageData.images.indexOfFirst { it.selected }
                val selectedViewHolder = detailGallery.findViewHolderForAdapterPosition(selectedPosition)
                if (selectedViewHolder?.itemView == null) {
                    return
                }
                sharedElements!![names!![0]] = selectedViewHolder.itemView.findViewById(R.id.detailItemImage)
            }
        }
    }

    companion object {
        private const val SAVED_CURRENT_PAGE_POSITION = "current_page_position"
    }
}
